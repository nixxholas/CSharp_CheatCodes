﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TextboxValidationSample
{
  public partial class UsingTryParse : Form
  {
    public UsingTryParse()
    {
      InitializeComponent();
    }

    private void btnCompute_Click(object sender, EventArgs e)
    {
      double b, h, area;

      if (double.TryParse(txtBase.Text, out b) == false) {
        MessageBox.Show("Please enter number for base!",
                        "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
        txtBase.Focus();
      }
      else if (double.TryParse(txtHeight.Text, out h) == false)
      {
        MessageBox.Show("Please enter number for height!",
                        "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
        txtHeight.Focus();
      }
      else {  //everything is okay then do what you gotta do
        area = 0.5 * b * h;
        lblArea.Text = "Area = " + area;  
      }
    }
  }
}
