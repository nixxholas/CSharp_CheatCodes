﻿namespace TextboxValidationSample
{
  partial class UsingTryCatch
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.label1 = new System.Windows.Forms.Label();
      this.label2 = new System.Windows.Forms.Label();
      this.txtBase = new System.Windows.Forms.TextBox();
      this.txtHeight = new System.Windows.Forms.TextBox();
      this.label3 = new System.Windows.Forms.Label();
      this.lblArea = new System.Windows.Forms.Label();
      this.btnCompute = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Location = new System.Drawing.Point(56, 9);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(153, 24);
      this.label1.TabIndex = 0;
      this.label1.Text = "Rectangle\'s Area";
      // 
      // label2
      // 
      this.label2.AutoSize = true;
      this.label2.Location = new System.Drawing.Point(29, 58);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(62, 24);
      this.label2.TabIndex = 1;
      this.label2.Text = "Base :";
      // 
      // txtBase
      // 
      this.txtBase.Location = new System.Drawing.Point(141, 55);
      this.txtBase.Name = "txtBase";
      this.txtBase.Size = new System.Drawing.Size(83, 29);
      this.txtBase.TabIndex = 2;
      // 
      // txtHeight
      // 
      this.txtHeight.Location = new System.Drawing.Point(141, 90);
      this.txtHeight.Name = "txtHeight";
      this.txtHeight.Size = new System.Drawing.Size(83, 29);
      this.txtHeight.TabIndex = 4;
      // 
      // label3
      // 
      this.label3.AutoSize = true;
      this.label3.Location = new System.Drawing.Point(29, 93);
      this.label3.Name = "label3";
      this.label3.Size = new System.Drawing.Size(75, 24);
      this.label3.TabIndex = 3;
      this.label3.Text = "Height :";
      // 
      // lblArea
      // 
      this.lblArea.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
      this.lblArea.Location = new System.Drawing.Point(29, 184);
      this.lblArea.Name = "lblArea";
      this.lblArea.Size = new System.Drawing.Size(191, 24);
      this.lblArea.TabIndex = 5;
      // 
      // btnCompute
      // 
      this.btnCompute.Location = new System.Drawing.Point(33, 134);
      this.btnCompute.Name = "btnCompute";
      this.btnCompute.Size = new System.Drawing.Size(190, 33);
      this.btnCompute.TabIndex = 6;
      this.btnCompute.Text = "Compute";
      this.btnCompute.UseVisualStyleBackColor = true;
      this.btnCompute.Click += new System.EventHandler(this.btnCompute_Click);
      // 
      // UsingTryCatch
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(260, 238);
      this.Controls.Add(this.btnCompute);
      this.Controls.Add(this.lblArea);
      this.Controls.Add(this.txtHeight);
      this.Controls.Add(this.label3);
      this.Controls.Add(this.txtBase);
      this.Controls.Add(this.label2);
      this.Controls.Add(this.label1);
      this.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
      this.Name = "UsingTryCatch";
      this.Text = "UsingTryCatch";
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.TextBox txtBase;
    private System.Windows.Forms.TextBox txtHeight;
    private System.Windows.Forms.Label label3;
    private System.Windows.Forms.Label lblArea;
    private System.Windows.Forms.Button btnCompute;
  }
}