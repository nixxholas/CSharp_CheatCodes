﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TextboxValidationSample
{
  public partial class UsingTryCatch : Form
  {
    public UsingTryCatch()
    {
      InitializeComponent();
    }

    private void btnCompute_Click(object sender, EventArgs e)
    {
      double b, h, area;

      try
      {
        b = double.Parse(txtBase.Text);
        h = double.Parse(txtHeight.Text);
        area = 0.5 * b * h;
        lblArea.Text = "Area = " + area;  
      }
      catch (FormatException ex) { //this exception is thrown when theres an error converting data
        MessageBox.Show("Please enter numbers for base and height!", 
                        "Error!", MessageBoxButtons.OK,MessageBoxIcon.Error);
      }
    }
  }
}
