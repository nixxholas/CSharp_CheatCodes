﻿namespace TextboxValidationSample
{
  partial class Main
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.btnTryParse = new System.Windows.Forms.Button();
      this.btnTryCatch = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // btnTryParse
      // 
      this.btnTryParse.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.btnTryParse.Location = new System.Drawing.Point(44, 12);
      this.btnTryParse.Name = "btnTryParse";
      this.btnTryParse.Size = new System.Drawing.Size(201, 53);
      this.btnTryParse.TabIndex = 0;
      this.btnTryParse.Text = "Error Handling using TryParse";
      this.btnTryParse.UseVisualStyleBackColor = true;
      this.btnTryParse.Click += new System.EventHandler(this.btnTryParse_Click);
      // 
      // btnTryCatch
      // 
      this.btnTryCatch.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.btnTryCatch.Location = new System.Drawing.Point(44, 81);
      this.btnTryCatch.Name = "btnTryCatch";
      this.btnTryCatch.Size = new System.Drawing.Size(201, 53);
      this.btnTryCatch.TabIndex = 1;
      this.btnTryCatch.Text = "Error Handling Using Try Catch";
      this.btnTryCatch.UseVisualStyleBackColor = true;
      this.btnTryCatch.Click += new System.EventHandler(this.btnTryCatch_Click);
      // 
      // Main
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(284, 154);
      this.Controls.Add(this.btnTryCatch);
      this.Controls.Add(this.btnTryParse);
      this.Name = "Main";
      this.Text = "Main";
      this.ResumeLayout(false);

    }

    #endregion

    private System.Windows.Forms.Button btnTryParse;
    private System.Windows.Forms.Button btnTryCatch;
  }
}