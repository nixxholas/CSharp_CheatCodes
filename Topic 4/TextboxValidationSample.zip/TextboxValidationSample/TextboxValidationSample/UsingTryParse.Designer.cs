﻿namespace TextboxValidationSample
{
  partial class UsingTryParse
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.btnCompute = new System.Windows.Forms.Button();
      this.lblArea = new System.Windows.Forms.Label();
      this.txtHeight = new System.Windows.Forms.TextBox();
      this.label3 = new System.Windows.Forms.Label();
      this.txtBase = new System.Windows.Forms.TextBox();
      this.label2 = new System.Windows.Forms.Label();
      this.label1 = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // btnCompute
      // 
      this.btnCompute.Location = new System.Drawing.Point(48, 149);
      this.btnCompute.Name = "btnCompute";
      this.btnCompute.Size = new System.Drawing.Size(190, 33);
      this.btnCompute.TabIndex = 13;
      this.btnCompute.Text = "Compute";
      this.btnCompute.UseVisualStyleBackColor = true;
      this.btnCompute.Click += new System.EventHandler(this.btnCompute_Click);
      // 
      // lblArea
      // 
      this.lblArea.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
      this.lblArea.Location = new System.Drawing.Point(44, 199);
      this.lblArea.Name = "lblArea";
      this.lblArea.Size = new System.Drawing.Size(191, 24);
      this.lblArea.TabIndex = 12;
      // 
      // txtHeight
      // 
      this.txtHeight.Location = new System.Drawing.Point(156, 105);
      this.txtHeight.Name = "txtHeight";
      this.txtHeight.Size = new System.Drawing.Size(83, 29);
      this.txtHeight.TabIndex = 11;
      // 
      // label3
      // 
      this.label3.AutoSize = true;
      this.label3.Location = new System.Drawing.Point(44, 108);
      this.label3.Name = "label3";
      this.label3.Size = new System.Drawing.Size(75, 24);
      this.label3.TabIndex = 10;
      this.label3.Text = "Height :";
      // 
      // txtBase
      // 
      this.txtBase.Location = new System.Drawing.Point(156, 70);
      this.txtBase.Name = "txtBase";
      this.txtBase.Size = new System.Drawing.Size(83, 29);
      this.txtBase.TabIndex = 9;
      // 
      // label2
      // 
      this.label2.AutoSize = true;
      this.label2.Location = new System.Drawing.Point(44, 73);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(62, 24);
      this.label2.TabIndex = 8;
      this.label2.Text = "Base :";
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Location = new System.Drawing.Point(71, 24);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(153, 24);
      this.label1.TabIndex = 7;
      this.label1.Text = "Rectangle\'s Area";
      // 
      // UsingTryParse
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(285, 266);
      this.Controls.Add(this.btnCompute);
      this.Controls.Add(this.lblArea);
      this.Controls.Add(this.txtHeight);
      this.Controls.Add(this.label3);
      this.Controls.Add(this.txtBase);
      this.Controls.Add(this.label2);
      this.Controls.Add(this.label1);
      this.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
      this.Name = "UsingTryParse";
      this.Text = "Error Handling using TryParse";
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.Button btnCompute;
    private System.Windows.Forms.Label lblArea;
    private System.Windows.Forms.TextBox txtHeight;
    private System.Windows.Forms.Label label3;
    private System.Windows.Forms.TextBox txtBase;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.Label label1;

  }
}

