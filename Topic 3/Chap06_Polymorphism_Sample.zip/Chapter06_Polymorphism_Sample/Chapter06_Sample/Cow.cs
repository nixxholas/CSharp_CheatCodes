﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Chapter06_Sample
{
    class Cow : Animal  //this is a subclass of Animal

    {
        private string m_tagId;

        public Cow(int a, int w, string t) : base(a, w) {
            m_tagId = t;
        }

        public Cow() { }

        public override void sound()
        {
            Console.WriteLine("Moo Moo");
        }

        public Cow(string id) {
            m_tagId = id;
        }

        public String TagId {
            get { return m_tagId; }
            set { m_tagId = value; }
        }



        public override string getInfo()
        {
            string info = base.getInfo();
            info += "\nTag ID : " + m_tagId;
            info += "\nAge : " + base.Age;
            info += "\nWeight : " + base.Weight;
            return info;
        }
    }
}
