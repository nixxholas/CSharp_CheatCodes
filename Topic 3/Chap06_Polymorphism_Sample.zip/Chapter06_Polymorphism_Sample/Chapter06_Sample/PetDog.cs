﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Chapter06_Sample
{
    class PetDog : Animal //this is a subclass of Animal
    {
        private string m_name;
        private string m_breed;



        public PetDog(int a, int w, string n, string b) : base(a,w) {
            m_name = n;
            m_breed = b;
        }

        public PetDog() { }

        public string Name {
            get { return m_name; }
            set { m_name = value; }
        }

        public string Breed
        {
            get { return m_breed; }
            set { m_breed = value; }
        }

        public override void sound()
        {
            Console.WriteLine("woof woof");
        }

        public override string getInfo()
        {
            string info = base.getInfo();
            info += "\nName : " + m_name;
            info += "\nBreed : " + m_breed;
            info += "\nAge : " + base.Age;
            info += "\nWeight : " + base.Weight;
            return info;
        }
    }
}
