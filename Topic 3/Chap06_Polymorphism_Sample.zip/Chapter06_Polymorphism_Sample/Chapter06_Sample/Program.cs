﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Chapter06_Sample
{
    class Program  {
        static void Main(string[] args)  {
            Animal[] animals = new Animal[4];

            animals[0] = new Cow(7, 120, "T220");
            animals[1] = new PetDog(5, 45, "Doggy", "Rottweiler");
            animals[2] = new PetDog(3, 11, "Rosy", "Beagles");
            animals[3] = new Cow(5, 1120, "755");

            for (int i = 0; i < animals.Length; i++)
            {
                printAnimalInfo(animals[i]);
            } //end for

            Console.ReadKey();
        }

        static void printAnimalInfo(Animal animal) {
            Console.WriteLine(animal.getInfo());
            animal.sound();
            Console.WriteLine("--------------");
        }
    }
}
