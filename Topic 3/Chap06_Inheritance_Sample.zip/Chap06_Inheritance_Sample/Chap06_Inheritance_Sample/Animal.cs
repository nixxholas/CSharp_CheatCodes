﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Chapter06_Sample
{
    class Animal  //this is the base class
    {
        private int m_age;
        private double m_weight;

        public Animal() { }

        public Animal(int a, int w) {
            m_age = a;
            m_weight = w;
        }

        public int Age {
            get { return m_age; }
            set { m_age = value; }
        }

        public double Weight
        {
            get { return m_weight; }
            set { m_weight = value; }
        }

        public string getInfo() { 
            return "Species : " + this.GetType().Name;   //return the class name
        }
    }
}
