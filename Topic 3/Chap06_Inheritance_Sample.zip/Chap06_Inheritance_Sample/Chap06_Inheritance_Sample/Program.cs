﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Chapter06_Sample
{
    class Program
    {
        static void Main(string[] args)    {
            Cow cow1 = new Cow(2, 120, "3454");

            Console.WriteLine(cow1.getInfo());  //calling base class method. Cow is an animal, thus cow can do whatever an animal can do.
            Console.WriteLine("------------------");
            Console.WriteLine(cow1.getCowInfo()); //calling method of the Cow class.. 

            Console.ReadKey();
        }
    }
}
